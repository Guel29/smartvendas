#!/usr/bin/env python3
"""Empacota o frontend já compilado e a API PHP, sem instaladores ou credenciais."""
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent.parent
source = root / 'dist'
assert (source / 'index.html').is_file(), 'Execute vite build antes.'
output = root / 'public/downloads/smartvendas-atualizacao-hostinger-php.zip'
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(source.rglob('*')):
        relative = file.relative_to(source)
        if file.is_file() and relative.parts[0] != 'downloads':
            if file.name in ('.env', 'db_config.json'):
                raise RuntimeError('Configuração privada não deve estar no build.')
            archive.write(file, relative.as_posix())
    archive.writestr('COMO-ATUALIZAR.txt',
        'Atualizacao para Hostinger com PHP e MySQL.\n'
        'Faca backup. Extraia pelo Gerenciador de Arquivos na pasta atual do site.\n'
        'Preserve .env e api/db_config.json. Nao apague o banco.\n'
        'Sem dados recebidos do agente, o painel informa a ausencia de dados reais.\n'
        'Atualize tambem o agente da loja para importar datas anteriores.\n')
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    assert archive.read('api/index.php') == (root / 'public/api/index.php').read_bytes()
print(output)
