#!/usr/bin/env python3
from pathlib import Path
import zipfile
root = Path(__file__).resolve().parent.parent
out = root / 'public/downloads/smartvendas-atualizacao-sincronizador.zip'
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in ('sync-agent.js', 'sync-agent.ts'):
        archive.write(root / 'public/downloads' / name, name)
    archive.writestr('COMO-ATUALIZAR.txt',
        'Atualizacao do sincronizador existente.\r\n'
        '1. Pare o sincronizador da loja que deseja atualizar.\r\n'
        '2. Faca uma copia de seguranca de sync-agent.js e sync-agent.ts.\r\n'
        '3. Substitua somente esses dois arquivos na pasta do sincronizador.\r\n'
        '4. Preserve .env, iniciador BAT, servico e node_modules.\r\n'
        '5. Inicie pelo mesmo iniciador ou servico que ja utiliza.\r\n'
        'Atualize a Hostinger primeiro. Este pacote acrescenta horarios reais de vendas e sangrias.\r\n'
        'Historico automatico: 62 dias por padrao, um dia anterior por ciclo. Aguarde a carga inicial.\r\n'
        'Se o .env ja tem SYNC_HISTORY_DAYS, esse valor prevalece; use 62 ou mais para cobrir o mes anterior.\r\n'
        'Nao inicie uma segunda copia do agente na mesma loja.\r\n')
with zipfile.ZipFile(out) as archive:
    assert archive.testzip() is None
print(out)
