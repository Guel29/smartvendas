import { test } from 'node:test';
import assert from 'node:assert/strict';
import { fetchHourlySales } from '../sync-agent';

test('curva consulta valores reais por hora com data parametrizada', async () => {
  const calls: any[] = [];
  const client = { query: async (sql: string, params?: any[]) => {
    calls.push({ sql, params });
    if (sql.includes('information_schema')) return { rows: [{ column_name: 'hora' }] };
    return { rows: [{ hour: '16:00', venda_liquida: 150, cupons: 3 }] };
  }};
  const rows = await fetchHourlySales(client as any, '2026-11-04');
  assert.equal(rows[0].venda_liquida, 150);
  assert.equal(rows[0].ticket_medio, 50);
  assert.deepEqual(calls[1].params, ['2026-11-04']);
  assert.match(calls[1].sql, /SUM\(vf.valor - COALESCE\(vf.troco, 0\)\)/);
});

test('não inventa distribuição quando não existe coluna de hora', async () => {
  assert.deepEqual(await fetchHourlySales({ query: async () => ({ rows: [] }) } as any, '2026-11-04'), []);
});

test('prioriza retirada individual do dia com horário em vez de saldo de operador', async () => {
  const pg = (await import('pg')).default;
  const { fetchVRData } = await import('../sync-agent');
  const connect = pg.Pool.prototype.connect;
  const queries: string[] = [];
  pg.Pool.prototype.connect = (async () => ({
    query: async (sql: string, params?: any[]) => {
      queries.push(sql);
      if (sql.includes('table_name, column_name')) return { rows: [
        ...['id','ecf','data','hora','valor'].map(column_name => ({table_name:'retirada',column_name})),
        ...['id','ecf','data'].map(column_name => ({table_name:'vendaoperador',column_name})),
        ...['retirada','id_vendaoperador'].map(column_name => ({table_name:'vendaoperadorfinalizadora',column_name})),
      ] };
      if (sql.includes('FROM pdv.retirada')) {
        assert.deepEqual(params, ['2026-11-04']);
        return { rows: [{id:'a',pdv:1,hora:'10:35:00',valor:15}, {id:'b',pdv:1,hora:'16:10:00',valor:25}] };
      }
      return { rows: [] };
    }, release() {},
  })) as any;
  try {
    const data = await fetchVRData('2026-11-04');
    assert.equal(data.sangrias.reduce((sum, row) => sum + row.valor, 0), 40);
    assert.equal(data.sangrias[1].hora, '16:10:00');
    assert.ok(!queries.some(sql => sql.includes('FROM pdv.vendaoperador vo')));
  } finally { pg.Pool.prototype.connect = connect; }
});
