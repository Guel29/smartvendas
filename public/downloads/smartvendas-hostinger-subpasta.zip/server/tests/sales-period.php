<?php
require __DIR__ . '/../../public/api/sales-data.php';
function check($condition, $message) { if (!$condition) throw new Exception($message); }
function getDailyVRIngest($pdo, $date, $store) {
    if ($store === 'missing') return null;
    return ['sale_date' => $date, 'generated_at' => $date . 'T18:00:00-03:00',
        'payments' => [['pdv' => 1, 'venda_liquida' => 10]],
        'pdvTotals' => [['pdv' => 1, 'cupons_totais' => 2]],
        'sangrias' => [['id' => $date, 'pdv' => 1, 'hora' => '16:35:40', 'valor' => 5]],
        'hourly' => [['hour' => '10:00', 'venda_liquida' => 10, 'cupons' => 2]]];
}
$_GET['date_end'] = '2026-11-04';
$data = getLastVRIngest(null, '2026-10-29', 'store-001');
check(count($data['payments']) === 7, 'Intervalo deve incluir 7 dias');
check(array_sum(array_column($data['payments'], 'venda_liquida')) === 70, 'Soma real de 7 dias');
check($data['pdvTotals'][0]['cupons_totais'] === 14, 'Cupons somados por PDV');
check(count($data['sangrias']) === 7 && $data['sangrias'][0]['hora'] === '16:35:40', 'Datas e horários de sangria preservados');
$_GET['date_end'] = '2026-10-31';
$data = getLastVRIngest(null, '2026-10-01', 'store-001');
check($data['received_days'] === 31, 'Mês anterior completo');
check(getLastVRIngest(null, '2026-10-01', 'missing') === null, 'Sem inventar dados para loja sem envio');
class Fixtures {
    function query($sql) { return new class {
        function fetchAll($mode) { return [['id_tipotef' => 91, 'nomecartao_pattern' => '%ESPECIAL%', 'category' => 'debito']]; }
    }; }
}
check(classifyTefPayment(new Fixtures(), ['id_tipotef' => 91, 'nomecartao' => 'CREDITO']) === 'debito', 'Regra salva deve prevalecer sobre classificação padrão');
check(classifyTefPayment(null, ['id_tipotef' => 0, 'nomecartao' => 'CARTAO ESPECIAL']) === 'debito', 'Padrão SQL com %');
echo "PASS: períodos de 7 dias e mês, ausência de dados, sangrias e regras TEF\n";

class DayArchive {
    function prepare($sql) { return new class {
        function execute($params) { return true; }
        function fetchAll($mode) { return [
            ['id' => 'manha', 'store_id' => 'store-001', 'pdv' => 1, 'hora' => '10:35:00', 'valor' => 15, 'data' => '2026-11-04'],
            ['id' => 'tarde', 'store_id' => 'store-001', 'pdv' => 1, 'hora' => '16:10:00', 'valor' => 25, 'data' => '2026-11-04'],
        ]; }
    }; }
}
$_GET['date_end'] = '2026-11-04';
$data = getLastVRIngest(new DayArchive(), '2026-11-04', 'store-001');
check(array_sum(array_column($data['sangrias'], 'valor')) === 40, 'Envio parcial não substitui sangrias persistidas de manhã e tarde');
echo "PASS: sangrias acumuladas do dia inteiro\n";
