import { test } from 'node:test';
import assert from 'node:assert/strict';
import { db } from '../db';

test('sangrias sobrevivem a envio vazio e troca de turno sem duplicar reenvios', () => {
  const store = db.getStoreById('store-001')!;
  const send = (date: string, sangrias: any[]) => db.ingestVRData(store, {
    batch_id: 'test', sale_date: date,
    payments: [{pdv: 1, finalizadora_id: 1, pagamento: 'DINHEIRO', cupons: 1, venda_bruta: 1000, troco: 0, venda_liquida: 1000}],
    pdvTotals: [{pdv: 1, cupons_totais: 1}], sangrias,
  });
  const total = (date: string) => db.getSalesSummary(store.id, date).sangria_total;
  const morning = {id: 'turno-manha', pdv: 1, hora: '10:00:00', valor: 100};
  send('2026-10-20', [morning]);
  send('2026-10-20', []);
  assert.equal(total('2026-10-20'), 100);
  send('2026-10-20', [{id: 'turno-tarde', pdv: 1, hora: '15:00:00', valor: 50}]);
  assert.equal(total('2026-10-20'), 150);
  send('2026-10-20', [morning]);
  assert.equal(total('2026-10-20'), 150);
  send('2026-10-20', [{...morning, valor: 80}]);
  assert.equal(total('2026-10-20'), 130);
  send('2026-10-21', []);
  assert.equal(total('2026-10-21'), 0);
  assert.equal(total('2026-10-20'), 130);
});

test('data sem sincronização não gera vendas nem estimativas por hora', () => {
  assert.deepEqual(db.getPDVSales('store-001', '2020-01-01'), []);
  assert.equal(db.getSalesSummary('store-001', '2020-01-01').venda_liquida, 0);
  assert.deepEqual(db.getHourlySales('store-001', '2020-01-01'), []);
});

test('edição TEF reclassifica transações recebidas na conciliação', () => {
  const store = db.getStoreById('store-001')!;
  db.ingestVRData(store, { batch_id: 'tef-edit', sale_date: '2026-11-02', payments: [], pdvTotals: [],
    tef: [{pdv: 1, nomecartao: 'CREDITO ESPECIAL', id_tipotef: 91, id_situacaotef: 1, valor_tef: 120, transacoes: 2}],
  });
  const rule = db.addTEFRule({id_tipotef: 91, category: 'credito', descricao: 'Especial', active: true});
  db.updateTEFRule(rule.id, {id_tipotef: 91, category: 'debito', descricao: 'Especial editado', active: true});
  const reconciliation = db.getTEFReconciliation(store.id, '2026-11-02');
  assert.equal(reconciliation.tef_by_category.debito, 120);
  assert.equal(reconciliation.details[0].categoria, 'debito');
});
