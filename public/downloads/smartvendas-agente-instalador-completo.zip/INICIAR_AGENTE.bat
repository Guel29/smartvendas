@echo off
setlocal
cd /d "%~dp0"
title Smart Vendas - Sincronizador
where node >nul 2>nul
if errorlevel 1 goto NO_NODE
if not exist "sync-agent.js" goto NO_AGENT
if not exist ".env" goto NO_ENV
if not exist "node_modules\pg" goto INSTALL
if not exist "node_modules\dotenv" goto INSTALL
goto RUN
:INSTALL
echo Instalando dependencias do sincronizador...
call npm install --omit=dev --no-audit --no-fund
if errorlevel 1 goto INSTALL_ERROR
:RUN
echo Iniciando sincronizador. Preserve esta janela aberta.
node sync-agent.js
echo.
echo O sincronizador foi encerrado. Confira as mensagens acima.
pause
exit /b
:NO_NODE
echo Node.js nao foi encontrado no PATH.
echo Instale a versao LTS em https://nodejs.org/ e abra esta janela novamente.
pause
exit /b 1
:NO_AGENT
echo Arquivo sync-agent.js nao encontrado nesta pasta.
echo Extraia os arquivos do ZIP antes de iniciar.
pause
exit /b 1
:NO_ENV
echo Arquivo .env nao encontrado nesta pasta.
echo Preserve e utilize o .env do sincronizador ja configurado.
echo Para primeira instalacao, execute CONFIGURAR.bat.
pause
exit /b 1
:INSTALL_ERROR
echo Nao foi possivel instalar as dependencias. Confira o erro acima.
pause
exit /b 1
