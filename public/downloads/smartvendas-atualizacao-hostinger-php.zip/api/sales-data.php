<?php
// Consulta de períodos com soma de snapshots reais por loja e dia.
function getLastVRIngest($pdo, $start, $store = 'all') {
    $end = $_GET['date_end'] ?? $start;
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end) || $end < $start) $end = $start;
    $first = new DateTimeImmutable($start);
    $last = new DateTimeImmutable($end);
    if ($first->diff($last)->days > 366) return null;
    $stores = [$store];
    if ($store === 'all' && $pdo) {
        try {
            $stores = $pdo->query('SELECT id FROM stores WHERE active = 1')->fetchAll(PDO::FETCH_COLUMN);
        } catch (Exception $e) { return null; }
    }
    if (!$stores) return null;
    $result = ['sale_date' => $start, 'date_end' => $end, 'payments' => [], 'pdvTotals' => [], 'tef' => [], 'sangrias' => [], 'hourly' => [], 'generated_at' => null];
    $received = 0;
    $sources = [];
    for ($day = $first; $day <= $last; $day = $day->modify('+1 day')) {
        $date = $day->format('Y-m-d');
        foreach ($stores as $id) {
            $data = getDailyVRIngest($pdo, $date, $id);
            if (!$data) continue;
            $received++;
            if (!empty($data['sangrias_source'])) $sources[$id . '_' . $date] = $data['sangrias_source'];
            foreach (['payments', 'pdvTotals', 'tef', 'sangrias', 'hourly'] as $field) {
                foreach (($data[$field] ?? []) as $row) {
                    $row['store_id'] = $id;
                    if ($field === 'sangrias') $row['data'] = $date;
                    $result[$field][] = $row;
                }
            }
            $at = $data['generated_at'] ?? $data['timestamp'] ?? null;
            if ($at && (!$result['generated_at'] || strtotime($at) > strtotime($result['generated_at']))) $result['generated_at'] = $at;
        }
    }
    // Registros persistidos do dia inteiro prevalecem sobre envios parciais do turno.
    if ($pdo) {
        try {
            $sql = 'SELECT id, store_id, pdv, hora, valor, motivo, operador, sale_date AS data FROM sangrias WHERE sale_date BETWEEN :start AND :end';
            $params = [':start' => $start, ':end' => $end];
            if ($store !== 'all') { $sql .= ' AND store_id = :store'; $params[':store'] = $store; }
            $statement = $pdo->prepare($sql . ' ORDER BY sale_date, pdv, hora');
            $statement->execute($params);
            $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
            if ($rows) {
                $rows = array_values(array_filter($rows, function($row) use ($sources) {
                    $source = $sources[$row['store_id'] . '_' . $row['data']] ?? null;
                    return !$source || strpos($row['id'], $source . ':') === 0;
                }));
                if ($rows) $result['sangrias'] = $rows;
            }
        } catch (Exception $e) { error_log('Smart Vendas: falha ao carregar sangrias do período.'); }
    }
    $pdvTotals = [];
    foreach ($result['pdvTotals'] as $row) {
        $key = $row['store_id'] . '_' . $row['pdv'];
        if (!isset($pdvTotals[$key])) $pdvTotals[$key] = ['pdv' => $row['pdv'], 'store_id' => $row['store_id'], 'cupons_totais' => 0];
        $pdvTotals[$key]['cupons_totais'] += intval($row['cupons_totais']);
    }
    $result['pdvTotals'] = array_values($pdvTotals);
    $result['received_days'] = $received;
    $result['expected_days'] = ($first->diff($last)->days + 1) * count($stores);
    return $received ? $result : null;
}

function classifyTefPayment($pdo, $transaction) {
    static $rules = null;
    if ($rules === null) {
        $rules = [];
        if ($pdo) {
            try { $rules = $pdo->query('SELECT id_tipotef, nomecartao_pattern, category FROM tef_classification_rules WHERE active = 1 ORDER BY created_at DESC, id DESC')->fetchAll(PDO::FETCH_ASSOC); }
            catch (Exception $e) { error_log('Smart Vendas: classificação TEF padrão em uso.'); }
        }
    }
    $card = strtoupper(trim($transaction['nomecartao'] ?? ''));
    $type = intval($transaction['id_tipotef'] ?? 0);
    foreach ($rules as $rule) {
        $codeMatch = $rule['id_tipotef'] !== null && intval($rule['id_tipotef']) === $type;
        $pattern = $rule['nomecartao_pattern'] ?? '';
        $expression = '/^' . str_replace(['%', '_'], ['.*', '.'], preg_quote(strtoupper($pattern), '/')) . '$/u';
        $nameMatch = $pattern !== '' && preg_match($expression, $card);
        if ($codeMatch || $nameMatch) return $rule['category'];
    }
    if ($type === 47 || strpos($card, 'PIX') !== false) return 'pix';
    if (strpos($card, 'DEB') !== false) return 'debito';
    if (strpos($card, 'CRED') !== false) return 'credito';
    if (strpos($card, 'ALIM') !== false || strpos($card, 'SODEXO') !== false || strpos($card, 'ALELO') !== false) return 'alimentacao';
    return 'outros';
}
