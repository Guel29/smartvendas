import { test } from 'node:test';
import assert from 'node:assert/strict';
import pg from 'pg';
import { getHistoricalDate, syncCycle } from '../sync-agent';

test('histórico atravessa meses, anos e ano bissexto sem mudar o dia civil', () => {
  assert.equal(getHistoricalDate('2026-01-01', 1), '2025-12-31');
  assert.equal(getHistoricalDate('2024-03-01', 1), '2024-02-29');
  assert.equal(getHistoricalDate('2026-11-03', 30), '2026-10-04');
});

test('consulta e envio preservam a data histórica solicitada', async () => {
  const originalConnect = pg.Pool.prototype.connect;
  const originalFetch = globalThis.fetch;
  const dates: string[] = [];
  let payload: any;
  pg.Pool.prototype.connect = (async () => ({
    query: async (_sql: string, params?: unknown[]) => {
      if (typeof params?.[0] === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(params[0])) dates.push(params[0]);
      return { rows: [] };
    },
    release() {},
  })) as any;
  globalThis.fetch = async (_url, options) => {
    payload = JSON.parse(String(options?.body));
    return new Response('{}', { status: 200 });
  };
  try {
    await syncCycle('2026-10-15');
    assert.ok(dates.length >= 3);
    assert.ok(dates.every(date => date === '2026-10-15'));
    assert.equal(payload.sale_date, '2026-10-15');
    assert.deepEqual(payload.pdvTotals, []);
  } finally {
    pg.Pool.prototype.connect = originalConnect;
    globalThis.fetch = originalFetch;
  }
});
