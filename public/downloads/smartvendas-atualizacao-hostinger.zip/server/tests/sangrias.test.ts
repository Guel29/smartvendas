import { test } from 'node:test';
import assert from 'node:assert/strict';
import { db } from '../db';

test('sangrias sobrevivem a envio vazio e troca de turno sem duplicar reenvios', () => {
  const store = db.getStoreById('store-001')!;
  const send = (date: string, sangrias: any[]) => db.ingestVRData(store, {
    batch_id: 'test', sale_date: date,
    payments: [{pdv: 1, finalizadora_id: 1, pagamento: 'DINHEIRO', cupons: 1, venda_bruta: 1000, troco: 0, venda_liquida: 1000}],
    pdvTotals: [{pdv: 1, cupons_totais: 1}], sangrias,
  });
  const total = (date: string) => db.getSalesSummary(store.id, date).sangria_total;
  const morning = {id: 'turno-manha', pdv: 1, hora: '10:00:00', valor: 100};
  send('2026-10-20', [morning]);
  send('2026-10-20', []);
  assert.equal(total('2026-10-20'), 100);
  send('2026-10-20', [{id: 'turno-tarde', pdv: 1, hora: '15:00:00', valor: 50}]);
  assert.equal(total('2026-10-20'), 150);
  send('2026-10-20', [morning]);
  assert.equal(total('2026-10-20'), 150);
  send('2026-10-20', [{...morning, valor: 80}]);
  assert.equal(total('2026-10-20'), 130);
  send('2026-10-21', []);
  assert.equal(total('2026-10-21'), 0);
  assert.equal(total('2026-10-20'), 130);
});
